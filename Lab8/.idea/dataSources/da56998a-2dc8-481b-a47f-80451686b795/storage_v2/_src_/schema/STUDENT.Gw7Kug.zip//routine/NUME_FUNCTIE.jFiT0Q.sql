create FUNCTION nume_functie (tabel nested_table_type) RETURN nested_table_type AS 
BEGIN 
    RETURN tabel;
END;
/

